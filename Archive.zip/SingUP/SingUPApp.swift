//
//  SingUPApp.swift
//  SingUP
//
//  Created by Muhammad Chandra Ramadhan on 29/04/25.
//

import SwiftUI

@main
struct SingUPApp: App {
    var body: some Scene {
        WindowGroup {
            MicPermissionView()
        }
    }
}
