//
//  Route.swift
//  SingUP
//
//  Created by Muhammad Chandra Ramadhan on 03/05/25.
//

struct Route {
    static let login: String = "/login"
    static let register: String = "/register"
}
